<?php

namespace App\Controllers;

class PemasukanSumberdanaEach extends BaseController
{
    public function index()
    {
        return view('pemasukan_sumberdana_each');
    }
}
