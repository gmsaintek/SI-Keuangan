<?php

namespace App\Controllers;

class PengeluaranKegiatanEach extends BaseController
{
    public function index()
    {
        return view('pengeluaran_kegiatan_each');
    }
}
