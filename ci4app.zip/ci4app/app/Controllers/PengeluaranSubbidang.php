<?php

namespace App\Controllers;
use App\Models\PengeluaranSubbidangModel;

class PengeluaranSubbidang extends BaseController
{
    public function index()
    {
        $model = new PengeluaranSubbidangModel();
        $data['subbidang'] = $model->findAll();
        return view('pengeluaran_subbidang', $data);
    }

    public function store()
    {
        $model = new PengeluaranSubbidangModel();
        $model->insert([
            'nama_bidang' => $this->request->getPost('nama_bidang'),
            'pengeluaran_sekarang' => $this->request->getPost('pengeluaran_sekarang'),
            'catatan' => $this->request->getPost('catatan'),
        ]);
        return redirect()->to(base_url('pengeluaran_subbidang'))->with('success', 'Data berhasil ditambahkan!');
    }

    public function update($id)
    {
        $model = new PengeluaranSubbidangModel();
        $model->update($id, [
            'nama_bidang' => $this->request->getPost('nama_bidang'),
            'pengeluaran_sekarang' => $this->request->getPost('pengeluaran_sekarang'),
            'catatan' => $this->request->getPost('catatan'),
        ]);
        return redirect()->to(base_url('pengeluaran_subbidang'))->with('success', 'Data berhasil diubah!');
    }

    public function delete($id)
    {
        $model = new PengeluaranSubbidangModel();
        $model->delete($id);
        return redirect()->to(base_url('pengeluaran_subbidang'))->with('success', 'Data berhasil dihapus!');
    }

    // Untuk cetak laporan (bisa export pdf/excel/csv sesuai kebutuhan)
    public function cetak()
    {
        $model = new PengeluaranSubbidangModel();
        $data['subbidang'] = $model->findAll();
        return view('pengeluaran_subbidang_print', $data);
    }
}
