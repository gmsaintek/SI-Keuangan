<?php

namespace App\Controllers;

class PengeluaranSubbidangEach extends BaseController
{
    public function index()
    {
        return view('pengeluaran_subbidang_each');
    }
}
