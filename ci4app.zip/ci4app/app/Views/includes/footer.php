<footer class="app-footer" data-bs-theme="dark">
    &copy; 2025 Gantari Mengwi. Semua Hak Dilindungi.
</footer>