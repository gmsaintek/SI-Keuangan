<div class="modal fade" id="cetaklaporan_subbidang_all" tabindex="-1" aria-labelledby="cetakLaporanSubbidangLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <form action="<?= base_url('pengeluaran_subbidang/cetak') ?>" method="get" target="_blank">
        <div class="modal-header">
          <h5 class="modal-title" id="cetakLaporanSubbidangLabel">Cetak Laporan Sub-bidang</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>
        <div class="modal-body">
          <div class="mb-3">
            <label for="format" class="form-label">Pilih Format</label>
            <select class="form-select" name="format" id="format">
              <option value="print">Cetak Langsung</option>
              <option value="pdf">Export PDF</option>
              <option value="excel">Export Excel</option>
              <option value="csv">Export CSV</option>
            </select>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
          <button type="submit" class="btn btn-warning">Cetak</button>
        </div>
      </form>
    </div>
  </div>
</div>
