<div class="modal fade" id="konfirmasi_selesai" tabindex="-1" aria-labelledby="konfirmasi_selesai" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
    
      <div class="modal-header">
        <h5 class="modal-title" id="konfirmasi_selesai">Konfirmasi</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>

      <div class="modal-body">
        <h6 class="modal-title">Anda yakin ingin menyelesaikan tahap ini?</h6>
      </div>

      <div class="modal-footer">
        <button class="btn btn-danger">Simpan</button>
        <button class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
      </div>

    </div>
  </div>
</div>
