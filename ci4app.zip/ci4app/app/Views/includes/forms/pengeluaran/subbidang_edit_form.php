<div class="modal fade" id="subbidang_edit_form_<?= $row['id'] ?>" tabindex="-1" aria-labelledby="editSubbidangLabel<?= $row['id'] ?>" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <form action="<?= base_url('pengeluaran_subbidang/update/' . $row['id']) ?>" method="post">
        <?= csrf_field() ?>
        <div class="modal-header">
          <h5 class="modal-title" id="editSubbidangLabel<?= $row['id'] ?>">Edit Sub-bidang</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>
        <div class="modal-body">
          <div class="mb-3">
            <label for="nama_bidang_<?= $row['id'] ?>" class="form-label">Nama Bidang</label>
            <input type="text" class="form-control" id="nama_bidang_<?= $row['id'] ?>" name="nama_bidang" value="<?= esc($row['nama_bidang']) ?>" required>
          </div>
          <div class="mb-3">
            <label for="pengeluaran_sekarang_<?= $row['id'] ?>" class="form-label">Pengeluaran Sekarang (Rp)</label>
            <input type="number" class="form-control" id="pengeluaran_sekarang_<?= $row['id'] ?>" name="pengeluaran_sekarang" min="0" value="<?= esc($row['pengeluaran_sekarang']) ?>" required>
          </div>
          <div class="mb-3">
            <label for="catatan_<?= $row['id'] ?>" class="form-label">Catatan</label>
            <input type="text" class="form-control" id="catatan_<?= $row['id'] ?>" name="catatan" value="<?= esc($row['catatan']) ?>">
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
          <button type="submit" class="btn btn-primary">Simpan</button>
        </div>
      </form>
    </div>
  </div>
</div>
