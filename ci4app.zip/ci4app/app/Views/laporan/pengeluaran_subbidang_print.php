<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <title>Laporan Sub-bidang Pengeluaran</title>
    <style>
        body { font-family: Arial, sans-serif; font-size: 14px; padding: 20px; }
        h2 { text-align: center; margin-bottom: 20px; }
        table { border-collapse: collapse; width: 100%; }
        th, td { border: 1px solid #333; padding: 8px; text-align: left; }
        th { background-color: #f8f8f8; }
        .text-center { text-align: center; }
        @media print {
            .no-print { display: none; }
        }
    </style>
</head>
<body>
    <div>
        <h2>Laporan Sub-bidang Pengeluaran</h2>
        <table>
            <thead>
                <tr>
                    <th>No.</th>
                    <th>Nama Bidang</th>
                    <th>Pengeluaran Sekarang (Rp)</th>
                    <th>Catatan</th>
                </tr>
            </thead>
            <tbody>
            <?php if (!empty($subbidang)): ?>
                <?php $no = 1; foreach ($subbidang as $row): ?>
                <tr>
                    <td><?= $no++ ?></td>
                    <td><?= esc($row['nama_bidang']) ?></td>
                    <td><?= number_format($row['pengeluaran_sekarang'], 2, ',', '.') ?></td>
                    <td><?= esc($row['catatan']) ?></td>
                </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="4" class="text-center">Tidak ada data.</td>
                </tr>
            <?php endif; ?>
            </tbody>
        </table>
        <br>
        <button onclick="window.print()" class="no-print">Print</button>
    </div>
</body>
</html>
